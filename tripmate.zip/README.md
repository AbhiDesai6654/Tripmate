# TripMate — Tourist Guide Hire (Demo)

This is a deployable Vite + React project (demo MVP) for TripMate. It includes:
- Guide listings (sample)
- Booking form that opens an email to desai1297@gmail.com
- "Pay via GPay" helper link with your UPI/GPay number: +91 7623897590
- Chat room with live translation using LibreTranslate public endpoint (replace for production)
- Company footer set to "Dad Corporate"

## Quickstart (locally)
1. Install Node.js (16+).
2. Run `npm install`.
3. Run `npm run dev` to start the dev server.
4. Open `http://localhost:5173`.

## Deploy to Vercel
1. Create a GitHub repo and push this project.
2. Sign in to Vercel and create a new project -> import the repo.
3. Vercel will detect `vite`. Set build command `npm run build` and output `dist`.
4. Deploy and add your custom domain.

## Notes & Next steps
- Replace the demo ChatRoom translator endpoint for production or subscribe to a translation API.
- Replace mailto booking with a backend booking API and integrate Razorpay for online payments.
- Implement secure file upload (S3) for certificates and an admin portal to verify guides.
