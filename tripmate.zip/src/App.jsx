import React, { useState } from 'react'
import ChatRoom from './components/ChatRoom'

const GPayNumber = '+91 7623897590'
const ContactEmail = 'desai1297@gmail.com'
const Company = 'Dad Corporate'
const SiteName = 'TripMate'

export default function App(){
  const [route, setRoute] = useState('home')
  const [booking, setBooking] = useState({name:'', email:'', date:'', notes:'', guide:'Local guide'})

  function go(r){ setRoute(r) }

  function handleBookingSubmit(e){
    e.preventDefault()
    const subject = encodeURIComponent('TripMate Booking Request — ' + booking.name)
    const body = encodeURIComponent(
      `Booking details:%0AName: ${booking.name}%0AEmail: ${booking.email}%0ADate: ${booking.date}%0AGuide: ${booking.guide}%0ANotes: ${booking.notes}%0A%0APlease contact via GPay/UPI: +91 7623897590`
    )
    window.location.href = `mailto:${ContactEmail}?subject=${subject}&body=${body}`
  }

  return (
    <div style={{fontFamily:'Inter, system-ui, -apple-system', padding:20, background:'#f3f4f6', minHeight:'100vh'}}>
      <div className="container">
        <header style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20}}>
          <h1>{SiteName} — Tourist Guide Hire</h1>
          <div>
            <button className="btn" onClick={()=>go('find')}>Find Guide</button>
            <button style={{marginLeft:8}} className="btn" onClick={()=>go('join')}>Join as Guide</button>
            <button style={{marginLeft:8}} className="btn" onClick={()=>go('contact')}>Contact</button>
          </div>
        </header>

        {route === 'home' && (
          <div className="grid" style={{gridTemplateColumns:'1fr 320px', gap:20}}>
            <div>
              <div className="card" style={{marginBottom:12}}>
                <h2>Welcome to {SiteName}</h2>
                <p className="muted">Hire verified local guides across India. Book by email or pay via GPay manually for now.</p>
                <div style={{marginTop:12}}>
                  <button className="btn" onClick={()=>go('find')}>Search Guides</button>
                </div>
              </div>

              <div className="card">
                <h3>How bookings work</h3>
                <ol>
                  <li>Search and select a guide.</li>
                  <li>Submit booking — an email will be sent to {ContactEmail}.</li>
                  <li>Pay via GPay (UPI) to +91 7623897590 and confirm with the guide.</li>
                </ol>
              </div>
            </div>

            <aside>
              <div className="card" style={{marginBottom:12}}>
                <h4>Quick contact</h4>
                <p className="muted">GPay / UPI: <strong>+91 7623897590</strong></p>
                <p className="muted">Email: <a href={'mailto:'+ContactEmail}>{ContactEmail}</a></p>
                <p className="muted">Company: {Company}</p>
              </div>

              <ChatRoom defaultLang="en" />
            </aside>
          </div>
        )}

        {route === 'find' && (
          <div>
            <div className="card" style={{marginBottom:12}}>
              <h2>Find Guides (Sample)</h2>
              <p className="muted">This is a demo listing. Replace with backend data when ready.</p>
            </div>

            <div className="grid" style={{gridTemplateColumns:'repeat(2, 1fr)'}}>
              {sampleGuides().map(g => (
                <div key={g.id} className="card">
                  <h3>{g.name} — {g.city}</h3>
                  <p className="muted">Languages: {g.languages.join(', ')} • {g.experience} yrs</p>
                  <p style={{marginTop:8}}>{g.short}</p>
                  <div style={{marginTop:8}}>
                    <button className="btn" onClick={()=>{ setBooking({...booking, guide: g.name}); go('book') }}>Book</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {route === 'book' && (
          <div className="card" style={{maxWidth:720}}>
            <h2>Book — {booking.guide}</h2>
            <form onSubmit={handleBookingSubmit}>
              <div style={{display:'grid', gap:8}}>
                <label>Your name</label>
                <input required value={booking.name} onChange={e=>setBooking({...booking, name:e.target.value})} />
                <label>Email</label>
                <input required value={booking.email} onChange={e=>setBooking({...booking, email:e.target.value})} />
                <label>Date</label>
                <input required type="date" value={booking.date} onChange={e=>setBooking({...booking, date:e.target.value})} />
                <label>Notes</label>
                <textarea value={booking.notes} onChange={e=>setBooking({...booking, notes:e.target.value})} />
                <div style={{display:'flex', gap:8, marginTop:8}}>
                  <button className="btn" type="submit">Send Booking Email</button>
                  <a className="btn" href={'upi://pay?pa=' + encodeURIComponent('+91 7623897590') } style={{background:'#059669'}}>Pay via GPay</a>
                  <button type="button" className="btn" onClick={()=>go('find')}>Cancel</button>
                </div>
                <p className="muted">Click 'Pay via GPay' to open your UPI app. This is a helper link — replace with Razorpay for automated checkout later.</p>
              </div>
            </form>
          </div>
        )}

        {route === 'join' && (
          <div className="card" style={{maxWidth:720}}>
            <h2>Join as Guide</h2>
            <p className="muted">Upload your certificates and we will contact you for verification.</p>
            <form onSubmit={(e)=>{ e.preventDefault(); alert('Application submitted (demo). We will contact you at ' + ContactEmail) }}>
              <div style={{display:'grid', gap:8}}>
                <input name="name" placeholder="Full name" required />
                <input name="city" placeholder="City" required />
                <input name="phone" placeholder="Phone" required />
                <input name="email" placeholder="Email" required />
                <input name="languages" placeholder="Languages (comma separated)" required />
                <label>Upload certificates (demo)</label>
                <input type="file" multiple />
                <div style={{display:'flex', gap:8}}>
                  <button className="btn" type="submit">Submit application</button>
                  <button type="button" className="btn" onClick={()=>go('home')}>Cancel</button>
                </div>
              </div>
            </form>
          </div>
        )}

        {route === 'contact' && (
          <div className="card">
            <h2>Contact</h2>
            <p className="muted">GPay: <strong>+91 7623897590</strong></p>
            <p className="muted">Email: <a href={'mailto:'+ContactEmail}>{ContactEmail}</a></p>
            <p className="muted">Company: {Company}</p>
          </div>
        )}

        <footer style={{marginTop:24, textAlign:'center'}} className="muted">
          © {new Date().getFullYear()} {Company} — {SiteName}. Platform fees apply. Guides must provide government certificates for verification.
        </footer>
      </div>
    </div>
  )
}

function sampleGuides(){
  return [
    { id: 'g1', name: 'Ramesh Kumar', city:'New Delhi', languages:['English','Hindi'], experience:8, short:'History & culture specialist' },
    { id: 'g2', name: 'Anita Sharma', city:'Mumbai', languages:['English','Hindi','Marathi'], experience:6, short:'Food & Bollywood tours' },
    { id: 'g3', name: 'Sunil Das', city:'Kolkata', languages:['English','Bengali'], experience:10, short:'Heritage and literature tours' },
  ]
}
