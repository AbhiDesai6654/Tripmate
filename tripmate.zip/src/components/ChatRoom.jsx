import React, { useState } from 'react'

// ChatRoom with translation using LibreTranslate public endpoint.
// NOTE: LibreTranslate public instance has rate limits. Replace with your own translator or API key in production.
export default function ChatRoom({ defaultLang = 'en' }) {
  const [messages, setMessages] = useState([
    { id: 1, from: 'Guide', text: 'Hello! How can I help you today?', lang: 'en' }
  ])
  const [input, setInput] = useState('')
  const [targetLang, setTargetLang] = useState(defaultLang)

  async function translateText(text, source, target) {
    try {
      const res = await fetch('https://libretranslate.de/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ q: text, source: source, target: target, format: 'text' })
      })
      const data = await res.json()
      return data.translatedText || text
    } catch (e) {
      console.error('Translate error', e)
      return text
    }
  }

  async function handleSend(e) {
    e.preventDefault()
    if (!input.trim()) return
    const userMsg = { id: Date.now(), from: 'You', text: input, lang: targetLang }
    setMessages(m => [...m, userMsg])
    setInput('')

    const guideReply = 'Great — I can guide you. Which city and dates are you planning?'
    const translated = await translateText(guideReply, 'en', targetLang)
    const replyMsg = { id: Date.now()+1, from: 'Guide', text: translated, lang: targetLang }
    setMessages(m => [...m, replyMsg])
  }

  return (
    <div className="card">
      <h3>Chat with Guide (Translator)</h3>
      <div style={{display:'flex', gap:8, marginBottom:8}}>
        <label className="muted">Your language:</label>
        <select value={targetLang} onChange={e=>setTargetLang(e.target.value)}>
          <option value="en">English</option>
          <option value="hi">Hindi</option>
          <option value="mr">Marathi</option>
          <option value="bn">Bengali</option>
          <option value="te">Telugu</option>
          <option value="ta">Tamil</option>
          <option value="gu">Gujarati</option>
          <option value="pa">Punjabi</option>
          <option value="ur">Urdu</option>
          <option value="fr">French</option>
          <option value="de">German</option>
          <option value="es">Spanish</option>
          <option value="zh">Chinese</option>
          <option value="ja">Japanese</option>
        </select>
      </div>

      <div style={{maxHeight:220, overflow:'auto', padding:8, border:'1px solid #e5e7eb', borderRadius:6, marginBottom:8}}>
        {messages.map(m => (
          <div key={m.id} style={{marginBottom:8}}>
            <strong>{m.from}:</strong> <span>{m.text}</span>
          </div>
        ))}
      </div>

      <form onSubmit={handleSend} style={{display:'flex', gap:8}}>
        <input value={input} onChange={e=>setInput(e.target.value)} placeholder="Type message..." style={{flex:1, padding:8, borderRadius:6, border:'1px solid #e5e7eb'}} />
        <button className="btn" type="submit">Send</button>
      </form>
      <p className="muted" style={{marginTop:8}}>Translation service: LibreTranslate (public). Replace endpoint in <code>src/components/ChatRoom.jsx</code> for production.</p>
    </div>
  )
}
